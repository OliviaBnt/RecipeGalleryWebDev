document.getElementById('hideIntro').onclick = function() {
  document.getElementById('intro').setAttribute('hidden', '')
};

function get_wiki_thumbnail (wikipageid) {
}
